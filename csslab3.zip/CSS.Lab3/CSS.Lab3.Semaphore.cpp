#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <iostream>

using namespace std;

sem_t semaphore;

void *threadRoutine(void *arg);

int main()
{
    sem_init(&semaphore, 0, 2);

    pthread_t th1, th2, th3;

    // Create threads
    pthread_create(&th1, NULL, threadRoutine, NULL);
    usleep(600000);
    pthread_create(&th2, NULL, threadRoutine, NULL);    
    usleep(600000);
    pthread_create(&th3, NULL, threadRoutine, NULL);

    // Join threads
    pthread_join(th1, NULL);
    pthread_join(th2, NULL);
    pthread_join(th3, NULL);

    sem_destroy(&semaphore);
}

void *threadRoutine(void *arg)
{
    pthread_t executingThread = pthread_self();

    cout << "Thread " << executingThread << ": Started." << endl;
    cout << "Thread " << executingThread << ":   Waiting on semaphore..." << endl;

    sem_wait(&semaphore);

    cout << "Thread " << executingThread << ":     Acquired semaphore." << endl;
    sleep(1);                  
    cout << "Thread " << executingThread << ":       Work done." << endl;

    sem_post(&semaphore);

    cout << "Thread " << executingThread << ":         Released semaphore." << endl;
    cout << "Thread " << executingThread << ":           Terminating." << endl;
}

#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <unistd.h>
#include <pthread.h>

#define CONSUMPTION_MIN_PORTION 3
#define PRODUCTION_GOAL 15

using namespace std;

int productsAvailable = 0;
int totalProductsProduced = 0;

pthread_mutex_t mutex;
pthread_cond_t condition;

void* producerThreadRoutine(void *args);
void* consumerThreadRoutine(void *args);

int main(int argc, char *argv[])
{
	pthread_t thProducer1, thProducer2, thConsumer;
	
	pthread_mutex_init(&mutex, NULL);
	pthread_cond_init(&condition, NULL);
	
    srand((unsigned) time(NULL) * getpid());

	pthread_create(&thProducer1, NULL, producerThreadRoutine, NULL);
    usleep(500000);
	pthread_create(&thProducer2, NULL, producerThreadRoutine, NULL);	
	pthread_create(&thConsumer, NULL, consumerThreadRoutine, NULL);
	
	pthread_join(thProducer1, NULL);
	pthread_join(thProducer2, NULL);
	pthread_join(thConsumer, NULL);
}

void* consumerThreadRoutine(void *args)
{
    pthread_t executingThread = pthread_self();

	cout << "    Consumer thread " << executingThread <<  ": Started." << endl;
	
	while(totalProductsProduced < PRODUCTION_GOAL)
	{
		pthread_mutex_lock(&mutex);

		while (productsAvailable < CONSUMPTION_MIN_PORTION)
		{
			pthread_cond_wait(&condition, &mutex);
		}

		cout << "    Consumer thread " << executingThread <<  ": Consuming available products..." << endl;
		productsAvailable = 0;
		cout << "    Consumer thread " << executingThread <<  ": Products available: 0" << endl;

		pthread_mutex_unlock(&mutex);
	}
}

void* producerThreadRoutine(void *args)
{
    pthread_t executingThread = pthread_self();

	cout << "Producer thread " << executingThread <<  ": Started." << endl;
	
	while (totalProductsProduced < PRODUCTION_GOAL)
	{
		pthread_mutex_lock(&mutex);

		productsAvailable++;
        totalProductsProduced++;

		cout << "Producer thread " << executingThread <<  ": Produced 1 item. ";
        cout << "Products available: " << productsAvailable << endl;

		if (productsAvailable >= CONSUMPTION_MIN_PORTION)
		{
			pthread_cond_signal(&condition);
		}

		pthread_mutex_unlock(&mutex);

        usleep(rand() % 3000000);
	}
}